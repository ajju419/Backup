package com.oneable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookFromApplication {
	
	private static final Logger logger = LoggerFactory.getLogger(BookFromApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(BookFromApplication.class, args);
//		logger.info("hello bonam.ajaryya@gmail.com");
		logger.debug("debug message");
//		logger.info("This is an info message");
//		logger.warn("Warning for this application");
//		logger.error("Seems error in the application");
	}

}
