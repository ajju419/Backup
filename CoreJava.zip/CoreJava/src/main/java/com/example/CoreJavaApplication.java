package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoreJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoreJavaApplication.class, args);
	}

}
