package com.example.corejava;

public class Test1 {

	public static void main(String[] args) {
		
		for(char ch='a'; ch<='z'; ch++) {
			System.out.println(ch);		
			for(char c='a';c<='z';c++) {
				
				System.out.println(ch+""+c);
				for(char d='a';d<='z';d++) {
					
					//System.out.println(ch+""+c+""+d);
				}
			}
		}

	}

}
