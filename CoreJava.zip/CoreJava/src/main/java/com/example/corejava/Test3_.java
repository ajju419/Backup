package com.example.corejava;

import java.util.Scanner;

public class Test3_ {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int rounds = sc.nextInt();
		printAlphabetSequence(rounds);
	}

	public static void printAlphabetSequence(int rounds) {
		int maxChar = (int) Math.pow(26, rounds);
		for (int i = 0; i < maxChar; i++) {
			StringBuilder sequence = new StringBuilder();
			int value = i;
			for (int j = 0; j < rounds; j++) {
				char c = (char) ('a' + (value % 26));
				sequence.insert(0, c);
				value /= 26;
			}
			System.out.println(sequence.toString());
		}
	}
}