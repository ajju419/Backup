package com.example.corejava;

import java.util.Arrays;

public class Test4_ {

	public static void main(String[] args) {
		String [] s1= {"ajju","zuzu","ducati","twinbirds"};
		Arrays.stream(s1).forEach(System.out::println);

	}

}
