package com.oneable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudMongoMayApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudMongoMayApplication.class, args);
	}

}
