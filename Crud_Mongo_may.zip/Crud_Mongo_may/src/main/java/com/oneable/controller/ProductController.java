package com.oneable.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.oneable.entity.Product;
import com.oneable.repository.ProductRepository;

@RestController
public class ProductController {
	
 @Autowired
	private ProductRepository repo;
	
 @PostMapping("/create-product")
	public  Product createProduct(@RequestBody Product product) {
		return repo.save(product);
	}
 
 @GetMapping("/list-products")
	public List<Product> getAllProducts(){
		return repo.findAll();
	}

}
