package com.oneable.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "MongoProductCrud")
public class Product {
	
	@Id
	public int productId;
	public String productName;
	public String productQuantity;
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(String productQuantity) {
		this.productQuantity = productQuantity;
	}
	public Product(int productId, String productName, String productQuantity) {
	
		this.productId = productId;
		this.productName = productName;
		this.productQuantity = productQuantity;
	}
	public Product() {
	;
	}
	
	
	
	

}
