package com.oneable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

import com.oneable.controller.RestTemplateConfig;

@SpringBootApplication
@Import(RestTemplateConfig.class)
public class IntegrationConfluenceApplication {
	
//	@Bean
//	public RestTemplate restTemplate() {
//	    return new RestTemplate();
//	}


	public static void main(String[] args) {
		SpringApplication.run(IntegrationConfluenceApplication.class, args);
	}

}
