package com.oneable.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class ConfluenceController {

    @Autowired
    private RestTemplate restTemplate;

    private final String confluenceUrl = "https://ajaryyaoneable.atlassian.net/wiki/home";

  //  private final String accessToken = "Bearer ATCTT3xFfGN00ABOf0tiKEvwKZYqAse072uf4lxGQnbyOecZN-fOUEBU94hpHLmBdKK3TMrfS5o2MUm1z5tgpPLTm3sHBpRLJmvE_PX9ncTwJyxlHtBntO5j8Y5kKwcqyVMEm6RMDA3-sby0EH4GJU7nn4Wg-ARbY1cSvmrNA9mtmguiDBcGV4M=06B107D4\r\n";
   private final String accessToken = "Bearer ATCTT3xFfGN0NtDMey3gae3jHZuOMP59d1ARsU8DsdFGh1XeWBTG4QUBvMZos1UGiGYImmQK7mPmkoHFbBC6fSRjXB_4Nof57cO2l8rtML_l2a_Bkm6klKtwbYJzism3VibovsURaeN18d79U6NDhjKgPa7SuMGNdNs1Jxu3cyRDSRSQibffX_I=C206A8C3";
    @GetMapping("/spaces")
    public String getSpaces() {
        String url = confluenceUrl + "/rest/api/space";
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + accessToken);
        headers.set("Accept", "application/json");
        HttpEntity<String> entity = new HttpEntity<>("parameters", headers);
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
        return response.getBody();
    }

    @GetMapping("/pages")
    public String getPages() {
        String url = confluenceUrl + "/rest/api/content";
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + accessToken);
        headers.set("Accept", "application/json");
        HttpEntity<String> entity = new HttpEntity<>("parameters", headers);
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
        return response.getBody();
    }
}


//package com.oneable.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpEntity;
//import org.springframework.http.HttpHeaders;
//import org.springframework.http.HttpMethod;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.client.RestTemplate;
//
//@RestController
//public class ConfluenceController {
//
//    @Autowired
//    private RestTemplate restTemplate;
//
//    private final String confluenceUrl = "https://ajaryyaoneable.atlassian.net/wiki/home";
//
//    @GetMapping("/spaces")
//    public String getSpaces(@RequestParam("access_token") String accessToken) {
//        String url = confluenceUrl + "/rest/api/space?access_token=" + accessToken;
//        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, null, String.class);
//        return response.getBody();
//    }
//
//    @GetMapping("/pages")
//    public String getPages(@RequestParam("access_token") String accessToken) {
//        String url = confluenceUrl + "/rest/api/content?access_token=" + accessToken + "&type=page&expand=history";
//        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, null, String.class);
//        return response.getBody();
//    }
//}
//
