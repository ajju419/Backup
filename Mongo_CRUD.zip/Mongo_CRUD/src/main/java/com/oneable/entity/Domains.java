package com.oneable.entity;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Domains {

	private String domain;
	private Data data;
	private String type;
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	
	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	public Domains() {
		
	}
	public Data getData() {
		return data;
	}
	public void setData(Data data) {
		this.data = data;
	}
	public Domains(String domain, Data data, String type) {
		
		this.domain = domain;
		this.data = data;
		this.type = type;
	}
	
	
}
