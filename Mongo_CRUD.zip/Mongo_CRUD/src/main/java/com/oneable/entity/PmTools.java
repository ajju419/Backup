package com.oneable.entity;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Product")
public class PmTools {
	
	private String toolName;
	private String url;
	private String apiToken;
	private String isActive;
	private String connectionName;
	public String getToolName() {
		return toolName;
	}
	public void setToolName(String toolName) {
		this.toolName = toolName;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getApiToken() {
		return apiToken;
	}
	public void setApiToken(String apiToken) {
		this.apiToken = apiToken;
	}
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	public String getConnectionName() {
		return connectionName;
	}
	public void setConnectionName(String connectionName) {
		this.connectionName = connectionName;
	}
	public PmTools(String toolName, String url, String apiToken, String isActive, String connectionName) {
		
		this.toolName = toolName;
		this.url = url;
		this.apiToken = apiToken;
		this.isActive = isActive;
		this.connectionName = connectionName;
	}
   
	public PmTools() {
		
	}
	
	

}
