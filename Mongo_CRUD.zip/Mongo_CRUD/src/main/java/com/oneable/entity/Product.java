package com.oneable.entity;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Product {
	
	private String productname;
	private String producttype;
	private String productaddress;
	private Settings settings;
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public String getProducttype() {
		return producttype;
	}
	public void setProducttype(String producttype) {
		this.producttype = producttype;
	}
	public String getProductaddress() {
		return productaddress;
	}
	public void setProductaddress(String productaddress) {
		this.productaddress = productaddress;
	}
	public Settings getSettings() {
		return settings;
	}
	public void setSettings(Settings settings) {
		this.settings = settings;
	}
	public Product() {
		
	}
	public Product(String productname, String producttype, String productaddress, Settings settings) {
		
		this.productname = productname;
		this.producttype = producttype;
		this.productaddress = productaddress;
		this.settings = settings;
	}
	
	
	
	
	
	

}
