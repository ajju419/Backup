package com.oneable.entity;

public class SessionRecording {
	
	private String recordingPath;

	public String getRecordingPath() {
		return recordingPath;
	}

	public void setRecordingPath(String recordingPath) {
		this.recordingPath = recordingPath;
	}

	public SessionRecording(String recordingPath) {
		
		this.recordingPath = recordingPath;
	}
	
	public SessionRecording() {
		
	}
	
	

}
