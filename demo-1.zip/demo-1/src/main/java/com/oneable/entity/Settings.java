package com.oneable.entity;

import java.util.List;

public class Settings {
	private List<Domains> domains;
	private SessionRecording sessionrecording;
	private PmTools pmtools;
	
	
	
	
	
	
	
	public List<Domains> getDomains() {
		return domains;
	}
	public void setDomains(List<Domains> domains) {
		this.domains = domains;
	}
	public PmTools getPmtools() {
		return pmtools;
	}
	public void setPmtools(PmTools pmtools) {
		this.pmtools = pmtools;
	}
	public SessionRecording getSessionrecording() {
		return sessionrecording;
	}
	public void setSessionrecording(SessionRecording sessionrecording) {
		this.sessionrecording = sessionrecording;
	}
	
	public Settings() {
			}
	public Settings(List<Domains> domains, SessionRecording sessionrecording, PmTools pmtools) {
		
		this.domains = domains;
		this.sessionrecording = sessionrecording;
		this.pmtools = pmtools;
	}
	
	
	
	

}
