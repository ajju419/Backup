package com.ajaryya.learnspringframework;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.ajaryya.learnspringframework.game.GameRunner;
import com.ajaryya.learnspringframework.game.GamingConsole;

public class AppGame02Gaming {

	public static void main(String[] args) {
		
    try (var context = new AnnotationConfigApplicationContext(GamingConfiguration.class)){
    	
    	context.getBean(GamingConsole.class).up();
    	context.getBean(GameRunner.class).run();
    	 
     }
	}

}
