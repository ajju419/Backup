package com.ajaryya.learnspringframework;

import org.springframework.context.annotation.Bean;

import com.ajaryya.learnspringframework.game.GameRunner;
import com.ajaryya.learnspringframework.game.GamingConsole;
import com.ajaryya.learnspringframework.game.MarioGame;

public class GamingConfiguration {

	@Bean
	public GamingConsole game() {
		var game = new MarioGame();
		return game;
	}
	
	@Bean
	public GameRunner gamerunner(GamingConsole game) {
		var gamerunner = new GameRunner(game);
		return gamerunner;
	}
	
}
