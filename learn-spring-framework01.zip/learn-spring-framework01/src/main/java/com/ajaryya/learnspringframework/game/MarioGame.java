package com.ajaryya.learnspringframework.game;

public class MarioGame implements GamingConsole {
	
	public void up() {
		System.out.println("mario up");
		
	}
	public void down() {
		System.out.println("mario down");
	}
	public void right() {
		System.out.println("mario right");
	}
	public void left() {
		System.out.println("mario left");
	}

}
