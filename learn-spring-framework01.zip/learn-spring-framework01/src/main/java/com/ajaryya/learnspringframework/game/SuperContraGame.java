package com.ajaryya.learnspringframework.game;

public class SuperContraGame implements GamingConsole{

	public void up() {
		System.out.println("supercontra up");
		
	}
	public void down() {
		System.out.println("supercontra down");
	}
	public void right() {
		System.out.println("supercontra right");
	}
	public void left() {
		System.out.println("supercontra left");
	}
}
