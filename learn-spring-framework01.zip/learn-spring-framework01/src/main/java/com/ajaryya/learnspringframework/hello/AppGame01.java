package com.ajaryya.learnspringframework.hello;

import java.util.Arrays;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class AppGame01 {

	public static void main(String[] args) {
		
		try(AnnotationConfigApplicationContext context =
				new AnnotationConfigApplicationContext(BasicConfiguration.class)){
			System.out.println(context.getBean("name"));
//			System.out.println(context.getBean("age"));
//			System.out.println(context.getBean("person"));
//			System.out.println(context.getBean("zuzu"));
			
			Arrays.stream(context.getBeanDefinitionNames())
			.forEach(System.out::println);
			System.out.println(context.getBeanDefinitionCount());
			
		}
//		
		

	}

}
