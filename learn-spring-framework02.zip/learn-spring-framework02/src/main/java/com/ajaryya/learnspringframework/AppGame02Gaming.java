package com.ajaryya.learnspringframework;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.ajaryya.learnspringframework.game.GameRunner;
import com.ajaryya.learnspringframework.game.GamingConsole;
import com.ajaryya.learnspringframework.game.MarioGame;

@Configuration
@ComponentScan("com.ajaryya.learnspringframework.game")

public class AppGame02Gaming {

	
	public static void main(String[] args) {

		try (var context = new AnnotationConfigApplicationContext(AppGame02Gaming.class)) {

			context.getBean(GamingConsole.class).up();
			context.getBean(GameRunner.class).run();

		}
	}

}
