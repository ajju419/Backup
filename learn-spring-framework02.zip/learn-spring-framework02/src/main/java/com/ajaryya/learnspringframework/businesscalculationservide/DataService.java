package com.ajaryya.learnspringframework.businesscalculationservide;

public interface DataService {
    
	public int[] retrieveData();

}
