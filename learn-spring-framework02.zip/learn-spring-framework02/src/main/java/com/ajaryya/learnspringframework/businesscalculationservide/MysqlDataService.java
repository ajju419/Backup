package com.ajaryya.learnspringframework.businesscalculationservide;

import org.springframework.stereotype.Component;

@Component
public class MysqlDataService implements DataService {

	@Override
	public int[] retrieveData() {
		int [] array2 = {1, 2, 3, 4, 5};
		return array2;
	}

}
