package com.ajaryya.learnspringframework.examples.ao;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.ajaryya.learnspringframework.game.GameRunner;
import com.ajaryya.learnspringframework.game.GamingConsole;
import com.ajaryya.learnspringframework.game.MarioGame;

@Configuration
@ComponentScan

public class SimpleSpringLauncher {

	public static void main(String[] args) {

		try (var context = new AnnotationConfigApplicationContext(SimpleSpringLauncher.class)) {

			Arrays.stream(context.getBeanDefinitionNames()).forEach(System.out::println);
		}
	}

}
