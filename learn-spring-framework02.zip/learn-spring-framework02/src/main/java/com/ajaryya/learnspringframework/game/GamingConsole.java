package com.ajaryya.learnspringframework.game;

public interface GamingConsole {
	
	public void up();
	public void down();
	public void right();
	public void left();
	

}
