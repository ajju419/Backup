package com.ajaryya.learnspringframework.game;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
//@Qualifier("marioGame")
@Primary
public class MarioGame implements GamingConsole {
	
	public void up() {
		System.out.println("mario up");
		
	}
	public void down() {
		System.out.println("mario down");
	}
	public void right() {
		System.out.println("mario right");
	}
	public void left() {
		System.out.println("mario left");
	}

}
